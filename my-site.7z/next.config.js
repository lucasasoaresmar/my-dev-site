const withMDX = require("@next/mdx")({
  extension: /\.mdx?$/,
});

module.exports = withMDX({
  pageExtensions: ["js", "jsx", "md", "mdx"],
  distDir: "build",
  webpack(config) {
    config.node = {
      fs: "empty",
    };

    return config;
  },
});
