---
Golang:
  value: Golang
  color: purple
  
Javascript:
  value: Javascript
  color: red

Csharp:
  value: Csharp
  color: green
---
